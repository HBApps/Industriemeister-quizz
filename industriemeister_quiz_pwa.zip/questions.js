
questions = [
  {
    frage: "Wie viele Volt hat eine gewöhnliche AA-Batterie?",
    antworten: ["1.2 V", "1.5 V", "3.0 V", "9.0 V"],
    richtigeAntwort: 1
  },
  {
    frage: "Was bedeutet der Begriff 'Ohm'?",
    antworten: ["Spannung", "Stromstärke", "Widerstand", "Leistung"],
    richtigeAntwort: 2
  }
];
